#!/bin/sh
cat /data/haproxy/haproxy.cfg /data/haproxy/host/*.cfg | haproxy -d -f /dev/stdin

