#!/bin/sh
nl-qdisc-add --dev=lo --parent=1:4 --id=40: --update plug --buffer &> /dev/null
cat /data/haproxy/haproxy.cfg /data/haproxy/host/*.cfg | haproxy -f /dev/stdin -p /var/run/haproxy.pid -sf $(cat /var/run/haproxy.pid)
nl-qdisc-add --dev=lo --parent=1:4 --id=40: --update plug--release-indefinite &> /dev/nullsleep
