# Contributing guidelines

Welcome to Kubernetes! If you are interested in contributing to the Metric-server code repo then checkout the [Contributor's Guide](https://github.com/kubernetes/community/tree/master/contributors/guide)

The [Kubernetes community repo](https://github.com/kubernetes/community) contains information on how the community is organized and other information that is pertinent to contributing. 
